# @presenton/export-core

A typed, local export engine for Presenton. The package exposes one task API,
creates every artifact on the local filesystem, and manages the Chromium and
temporary resources used by each invocation. Callers can also supply a browser
to reuse across invocations.

It does not include an HTTP server, Lambda handler, object-storage adapter, or
CLI. Applications can add those boundaries around the core if they need them.

## Install

The package is distributed as a tarball attached to each
[GitHub Release](https://github.com/presenton/export-core/releases), not through
the npm registry. Each release contains two drop-in editions:

- `presenton-export-core-<version>.tgz` contains all features, including low-
  and high-quality export.
- `presenton-export-core-opensource-<version>.tgz` only supports low-quality
  export. Its `export` and `html-to-any` task types do not accept `quality`, and
  the runtime always uses low quality.

The open-source archive is also mirrored as the only package attached to the
matching release in
[`presenton/presenton-export`](https://github.com/presenton/presenton-export/releases).

Install the full release directly from GitHub (replace the version as needed):

```sh
npm install https://github.com/presenton/export-core/releases/download/v0.1.0/presenton-export-core-0.1.0.tgz
```

To install the open-source edition instead:

```sh
npm install https://github.com/presenton/export-core/releases/download/v0.1.0/presenton-export-core-opensource-0.1.0.tgz
```

Alternatively, download `presenton-export-core-<version>.tgz` from the release
page and install the local file. The open-source archive installs under the same
`@presenton/export-core` package name, so application imports are identical.

```sh
npm install ./presenton-export-core-0.1.0.tgz
```

Node.js 22.12 or newer is required. Puppeteer installs its managed browser for
browser-backed tasks. If that browser is missing from Puppeteer's cache at
runtime, Export Core downloads it and retries the launch once.

## Run a task

```ts
import { runTask, type ExportPptxFromJsonTask } from "@presenton/export-core";

const task: ExportPptxFromJsonTask = {
  type: "pptx-from-json",
  data: {
    name: "Quarterly report",
    slides: [{ shapes: [] }],
  },
};

const response = await runTask(task, {
  outputDirectory: "/var/app/exports",
  tempDirectory: "/var/app/tmp",
});

console.log(response.filePath);
```

`runTask` infers the response type from the task. It is the package's only
runtime export; task and option types are exported for TypeScript consumers.

## Options

```ts
interface RunTaskOptions {
  outputDirectory?: string;
  tempDirectory?: string;
  cleanupTempDirectory?: boolean;
  browserLaunchOptions?: import("puppeteer").LaunchOptions;
  puppeteerCacheDirectory?: string;
  getBrowser?: () =>
    | import("puppeteer").Browser
    | Promise<import("puppeteer").Browser>;
  urlConfigs?: readonly UrlConfig[];
  modifyWindow?: () => void;
}
```

- `outputDirectory` defaults to `./exports`. Returned artifacts remain here.
- `tempDirectory` defaults to the operating-system temporary directory and is
  used as the parent for a unique per-task directory.
- `cleanupTempDirectory` defaults to `true`. Set it to `false` to retain the
  unique `presenton-export-*` task directory after success or failure.
- `browserLaunchOptions` is passed to Puppeteer for browser-backed tasks. An
  explicit browser, executable path, or release channel is honored; custom
  executable paths and channels do not fall back to Puppeteer's managed browser.
- `puppeteerCacheDirectory` overrides the directory used to find and download
  Puppeteer's managed browser. This is useful in serverless environments; for
  example, use a writable path such as `/tmp/puppeteer` on AWS Lambda or point
  it at a browser cache included in a Lambda layer. It is ignored when
  `getBrowser`, an executable path, or a release channel owns browser provisioning.
- `getBrowser` asks a caller-owned browser manager or pool for a healthy browser
  at the start of each browser-backed task. It may be synchronous or asynchronous.
  Export Core validates that the returned browser is connected, but does not
  close it or retry a task if it crashes midway. `browserLaunchOptions` is
  ignored when `getBrowser` is set.
- `urlConfigs` applies credentials to matching browser requests and matching
  local Node.js fetches, including remote PPTX sources, images, and fonts.
- `modifyWindow` runs in the browser context before page content loads. The
  callback must be self-contained and cannot close over Node.js values.

For example, a caller can provide frontend runtime configuration without adding
application-specific fields to the task:

```ts
await runTask(task, {
  modifyWindow: () => {
    const target = window as typeof window & {
      env?: Record<string, string>;
    };
    target.env = {
      ...(target.env ?? {}),
      NEXT_PUBLIC_FAST_API: "https://api.example.com",
    };
  },
});
```

The package launches the browser lazily and closes it before returning unless a
caller-owned browser is supplied by `getBrowser`. It closes the pages it creates
and deletes intermediate files. Only returned output artifacts and any assets
required by those artifacts are retained.

For a warm browser that can be replaced after a crash, use `getBrowser`:

```ts
import puppeteer, { type Browser } from "puppeteer";
import { runTask } from "@presenton/export-core";

let browser: Browser | undefined;

async function getBrowser() {
  if (!browser?.connected) {
    browser = await puppeteer.launch({ headless: true });
  }
  return browser;
}

await runTask(task, { getBrowser, outputDirectory: "./exports" });
```

If the browser crashes during a task, that invocation rejects without an
automatic retry. The next invocation calls `getBrowser` again, allowing the
manager to replace the disconnected process.

## Per-URL headers and cookies

Cloudflare Access and other protected resources can be configured without
global environment variables or host-specific code:

```ts
import { runTask } from "@presenton/export-core";

const urlConfigs = [
  {
    // `origin` is the default: matches every URL on this origin.
    url: "https://slides.example.com",
    headers: {
      "CF-Access-Client-Id": process.env.CF_CLIENT_ID!,
      "CF-Access-Client-Secret": process.env.CF_CLIENT_SECRET!,
    },
    cookies: {
      auth_token: "signed-session-value",
    },
  },
  {
    url: "https://api.example.com/v1/",
    match: "prefix",
    headers: {
      Authorization: "Bearer application-token",
    },
    cookies: [
      {
        name: "session",
        value: "value",
        path: "/v1",
        secure: true,
        httpOnly: true,
        sameSite: "Lax",
      },
    ],
  },
] satisfies NonNullable<Parameters<typeof runTask>[1]>["urlConfigs"];

const result = await runTask(
  {
    type: "export",
    url: "https://slides.example.com/presentations/123",
    format: "pdf",
  },
  { outputDirectory: "./exports", urlConfigs }
);
```

The matching modes are:

- `origin` (default): same protocol, host, and port.
- `prefix`: the request URL starts with the configured URL.
- `exact`: the complete URL matches, including path and query string.

When multiple entries match, their headers and cookies are combined in list
order; later values replace earlier values with the same key.

## Tasks and responses

| Task type | Result |
| --- | --- |
| `export` | Local PDF, PPTX, or PNG ZIP file |
| `html-to-any` | Local PDF, PPTX, or PNG ZIP file |
| `pptx-from-json` | Local PPTX file |
| `pptx-to-html` | Local JSON file plus its retained asset directory |
| `pptx-to-json` | Local JSON file plus its retained asset directory |
| `html-to-image` | Local PNG file |
| `html-to-images` | Local PNG files |
| `json-to-html` | HTML string |
| `json-to-image` | Local PNG file |
| `json-to-images` | Local PNG files |

`json-to-html` preserves each image element's `data` value as the HTML image
path. Local image inlining is performed by `json-to-image` and
`json-to-images`.

`export` and `html-to-any` tasks can use `replaceUrls` to rewrite exact asset
URLs or URL prefixes when PPTX images are downloaded. It does not rewrite the
page URL, source-template URLs, or the source-notes URL.

File responses use these typed shapes:

```ts
interface ExportFileResponse {
  type: "file";
  filePath: string; // absolute local path
  url: string;      // file:// URL for the same path
  mimeType: string;
}

interface ExportFilesResponse {
  type: "files";
  filePaths: string[];
  urls: string[];
  mimeType: string;
}

```

## Development

```sh
npm install
npm run typecheck
npm test
npm run test:types
npm run build
npm run build:pack
```

The build bundles the TypeScript entry point as ESM with esbuild, obfuscates the
bundle with `javascript-obfuscator`, and emits only `dist/index.js` and the
bundled `dist/index.d.ts` declaration. `npm run build:pack` also creates the npm
package tarball for local installation and release checks. Pushing a tag that
matches the package version (for example, `v0.1.0`) runs the release workflow,
which tests, builds, and packs the package before creating a GitHub Release and
attaching the tarball. The workflow does not publish to the npm registry.

Run the export eval suites with:

```sh
npm run eval:pptx
npm run eval:pdf
npm run eval:conversions
npm run eval:pptx-corpus
npm run test:export:parallel
```

The conversion eval suite covers PPTX-to-HTML, PPTX-to-JSON, and
HTML-to-image through the public task API. Each conversion can also be run with
`eval:pptx-to-html`, `eval:pptx-to-json`, or `eval:html-to-image`.
`eval:pptx-corpus` discovers every `.pptx` under `eval/assets`, validates both
PPTX-to-JSON and PPTX-to-HTML conversion, and compares text, tables, charts,
and visual-element coverage with the sibling Export OpenSource converter. Set
`PPTX_REFERENCE_EXPORT_ROOT` when that repository is not located at
`../export-opensource`.

The parallel smoke eval can be limited to one format with
`test:export:pptx:parallel`, `test:export:pdf:parallel`, or
`test:export:png:parallel`. The PPTX and PDF evals also provide
`test:export:<format>:parallel:same-browser` variants. See
[Eval presentation assertions](docs/eval-asserts.md) for prerequisites,
generated artifacts, and concurrency controls.

Additional implementation notes are available for
[export quality](docs/export-quality.md),
[PowerPoint compatibility](docs/powerpoint-compatibility.md), and [image
post-processing](docs/image-post-processing.md).

The runtime implementation is TypeScript only; Python is not required.
